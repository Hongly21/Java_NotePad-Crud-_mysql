-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2025 at 06:14 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jdbc`
--

-- --------------------------------------------------------

--
-- Table structure for table `note_tbl`
--

CREATE TABLE `note_tbl` (
  `id` int(11) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `note_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `note_tbl`
--

INSERT INTO `note_tbl` (`id`, `date_created`, `note_desc`) VALUES
(22, '2025-06-27 09:53:27', 'Hello, My name is Hongly. Now i am a student at Norton University.\nMy major is Computer Science.\nThis is my final project of Java programming.'),
(23, '2025-06-27 09:54:07', 'Shoping List: \n-vegetable\n-food\n-drink\n-fish\n-coke \n-meat\n'),
(27, '2025-08-15 02:28:04', 'Test:\n-12\n-12\n-23\n-34\n-34'),
(28, '2025-08-27 04:13:09', 'List: \n-AAA\n-CC\n-DDD');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `note_tbl`
--
ALTER TABLE `note_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `note_tbl`
--
ALTER TABLE `note_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
