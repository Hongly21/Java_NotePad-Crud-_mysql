package note_pad;

import java.util.ArrayList;

public class ArrayListObject {
    public static void main(String[] args){
        ArrayList <JdbcNote> list=new ArrayList();
        list.add(new JdbcNote(1,"Note1"));
        list.add(new JdbcNote(2,"Note2"));
        for(int i=0; i<list.size(); i++){
            JdbcNote note=list.get(i);
            System.out.println(note.id +" "+ note.text);
        }
    }
}
class JdbcNote{
    int id;
    String text;
    public JdbcNote(int id, String text){
        this.id=id;
        this.text=text;
    }
}
