package note_pad;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import java.sql.*;



public class NotePad extends JFrame {
    SimpleButton lbAdd= new SimpleButton("Add");
    SimpleButton lbUpdate= new SimpleButton("Update");
    SimpleButton lbDelete= new SimpleButton("Delete");
    Connection connection;
    Statement statement;


    DefaultListModel model = new DefaultListModel<>();
    JList<String> list = new JList<>(model);


    static ArrayList<Note> notes = new ArrayList<Note>();


    public NotePad(){
        JPanel menu=new JPanel(new FlowLayout(FlowLayout.LEFT));
        menu.add(lbAdd); menu.add(lbUpdate); menu.add(lbDelete);
        add(menu, BorderLayout.NORTH);
        add(new JScrollPane(list), BorderLayout.CENTER);

        setSize(500, 275);
        setLocationRelativeTo(null);
        setVisible(true); //meat


        initNote();
        customizeList();


        lbAdd.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addNote();
            }
        });
        lbDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index=list.getSelectedIndex();
                if(index!=-1){
                    deleteNote(index);
                }
            }
        });
        lbUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index=list.getSelectedIndex();
                if(index !=-1){
                    updateNote(index);
                }
            }
        });


    }



    void initNote(){
        try {
            connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/jdbc", //Database name
                    "root", //user
                    "");
            statement = connection.createStatement();


            ResultSet resultSet = statement.executeQuery("select * from note_tbl");
            while (resultSet.next()) { //retrieve rows of table tbl_note

                notes.add(new Note(resultSet.getInt("id"),
                        resultSet.getString("note_desc")));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();

        }
        for(int i=0; i<notes.size(); i++){ // copy from notes to jlist model
            model.addElement(notes.get(i).toString());
        }




    }
    void customizeList() {
        list.setCellRenderer(new ListCellRenderer<String>() {
            @Override
            public Component getListCellRendererComponent(
                    JList<? extends String> list,
                    String value,
                    int index,
                    boolean isSelected,
                    boolean cellHasFocus) {

                JTextArea textArea = new JTextArea(value);
                textArea.setLineWrap(true);                     // Allow lines to wrap
                textArea.setWrapStyleWord(true);                // Wrap at word boundaries
                textArea.setOpaque(true);                       // Show background color
                textArea.setMargin(new Insets(5, 15, 5, 5));    // Add internal padding

                if (isSelected) {
                    textArea.setBackground(list.getSelectionBackground());
                    textArea.setForeground(list.getSelectionForeground());
                } else {
                    textArea.setBackground(list.getBackground());
                    textArea.setForeground(list.getForeground());
                }

                return textArea;
            }
        });
    }



    void addNote() {
        SimpleButton btSave = new SimpleButton("Add note");
        JTextArea textArea = new JTextArea();

        JDialog addDialog = new JDialog();
        addDialog.setLayout(new BorderLayout());

        JPanel savePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        savePanel.add(btSave);

        textArea.setMargin(new Insets(5, 5, 5, 0));

        addDialog.add(savePanel, BorderLayout.NORTH);
        addDialog.add(textArea, BorderLayout.CENTER);

        addDialog.setSize(400, 200);
        addDialog.setLocationRelativeTo(null);
        addDialog.setVisible(true);

        textArea.requestFocus();

        btSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = textArea.getText();
                if (!text.isEmpty()) {
                    try {
                        PreparedStatement preparedStatement = connection.prepareStatement(
                                "INSERT INTO note_tbl(date_created, note_desc) VALUES (current_timestamp(), ?)"
                        );
                        preparedStatement.setString(1, text);
                        preparedStatement.executeUpdate();

                        ResultSet rs = statement.executeQuery("SELECT last_insert_id()");
                        int id = 0;
                        while (rs.next()) {
                            id = rs.getInt(1);
                        }

                        notes.add(new Note(id, text));
                        model.addElement(text);
                    } catch (SQLException ex) {
                        System.out.println(ex.getMessage());
                        throw new RuntimeException(ex);
                    }
                }
                addDialog.dispose();
            }
        });


    }
    void deleteNote(int index){
        try{
            PreparedStatement preparedStatement=
                    connection.prepareStatement("delete from note_tbl where id=?");
            preparedStatement.setInt(1,notes.get(index).id);
            preparedStatement.executeUpdate();
            notes.remove(index);
            model.removeElementAt(index);

        }catch (SQLException e){
            System.out.println(e.getMessage());
            throw new RuntimeException(e);
        }
    }
    void updateNote(int index) {
        // Get selected note text
        String text = notes.get(index).text;

        // Create components
        JButton btUpdate = new JButton("Update");
        JTextArea textArea = new JTextArea(text);
        textArea.setMargin(new Insets(5, 5, 5, 0));

        // Configure button appearance
        btUpdate.setOpaque(false);
        btUpdate.setContentAreaFilled(false);
        btUpdate.setBorderPainted(false);

        // Create panel and dialog
        JPanel updatePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        updatePanel.add(btUpdate);

        JDialog updateDialog = new JDialog();
        updateDialog.setLayout(new BorderLayout());
        updateDialog.add(updatePanel, BorderLayout.NORTH);
        updateDialog.add(new JScrollPane(textArea), BorderLayout.CENTER); // Scroll for long notes

        // Set dialog properties
        updateDialog.setSize(400, 200);
        updateDialog.setLocationRelativeTo(null);
        updateDialog.setVisible(true);
        textArea.requestFocus();

        btUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = textArea.getText(); // Get updated text
                if (!text.isEmpty()) {
                    try {
                        PreparedStatement preparedStatement = connection.prepareStatement(
                                "UPDATE note_tbl SET note_desc = ? WHERE id = ?"
                        );
                        preparedStatement.setString(1, text); // Set new note text
                        preparedStatement.setInt(2, notes.get(index).id); // Set note ID to update
                        preparedStatement.executeUpdate();

                        // Update the model and local note list
                        model.setElementAt(text, index);
                        notes.set(index, new Note(notes.get(index).id, text));

                        // Optional: fetch last inserted ID (not needed for update, but harmless)
                        ResultSet rs = statement.executeQuery("SELECT last_insert_id()");
                        while (rs.next()) {
                            int id = rs.getInt(1);
                            System.out.println(id);
                        }
                    } catch (SQLException ex) {
                        System.out.println(ex.getMessage());
                        throw new RuntimeException(ex);
                    }
                }
                updateDialog.dispose(); // Close the update dialog
            }
        });

    }



    public static void main(String[] args){
        new NotePad();
    }


    public class Note {
        int id;
        String text;
        public Note(int id, String text){
            this.id=id;
            this.text=text;
        }


        @Override
        public String toString() {
            return text;


        }
    }


}
