package note_pad;

import javax.swing.*;

public class SimpleButton extends JButton {
    public SimpleButton(String label){
        super(label);
        setOpaque(true);
        setContentAreaFilled(false);
        setBorderPainted(false);
    }
}
